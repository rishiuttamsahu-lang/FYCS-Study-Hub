import { useState, useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import { doc, updateDoc, increment } from "firebase/firestore";
import { db } from "../firebase";
import { Download, ShieldCheck, FileText, AlertCircle } from "lucide-react";

// Reusable Banner Ad Component for Adsterra/AdSense style scripts
function BannerAd({ adKey, format, height, width, scriptSrc }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;
    
    // Clear any existing content
    containerRef.current.innerHTML = "";

    const atOptions = {
      key: adKey,
      format: format,
      height: height,
      width: width,
      params: {}
    };
    
    // Create config script
    const confScript = document.createElement("script");
    confScript.type = "text/javascript";
    confScript.innerHTML = `window.atOptions = ${JSON.stringify(atOptions)};`;
    containerRef.current.appendChild(confScript);

    // Create execution script
    const invokeScript = document.createElement("script");
    invokeScript.type = "text/javascript";
    invokeScript.src = scriptSrc;
    containerRef.current.appendChild(invokeScript);
  }, [adKey, format, height, width, scriptSrc]);

  return (
    <div 
      ref={containerRef} 
      style={{ width: `${width}px`, height: `${height}px` }} 
      className="bg-zinc-900 border border-white/5 rounded-xl overflow-hidden flex items-center justify-center"
    />
  );
}

// Reusable Native Wrapper Ad Component
function NativeAdSlot({ containerId, scriptSrc }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;
    containerRef.current.innerHTML = "";
    
    const div = document.createElement("div");
    div.id = containerId;
    containerRef.current.appendChild(div);

    const script = document.createElement("script");
    script.async = true;
    script.setAttribute("data-cfasync", "false");
    script.src = scriptSrc;
    containerRef.current.appendChild(script);
  }, [containerId, scriptSrc]);

  return <div ref={containerRef} className="w-full max-w-[728px]" />;
}

export default function DownloadGate() {
  const [searchParams] = useSearchParams();
  const fileId = searchParams.get("id");
  const materialId = searchParams.get("materialId");
  const fileName = searchParams.get("name") || "file";

  const [stage, setStage] = useState("idle"); // idle | processing | ready
  const [progress, setProgress] = useState(0);

  // Load popunder ad script on mount
  useEffect(() => {
    const popunderScript = document.createElement("script");
    popunderScript.type = "text/javascript";
    popunderScript.src = "https://pl30438978.effectivecpmnetwork.com/64/10/e4/6410e414e7ba94bfac887476372ef40e.js";
    popunderScript.async = true;
    document.body.appendChild(popunderScript);

    return () => {
      document.body.removeChild(popunderScript);
    };
  }, []);

  const startProcess = () => {
    setStage("processing");
    const totalMs = 7000;
    const stepMs = 100;
    let elapsed = 0;

    const interval = setInterval(() => {
      elapsed += stepMs;
      setProgress(Math.min(100, Math.round((elapsed / totalMs) * 100)));
      if (elapsed >= totalMs) {
        clearInterval(interval);
        setStage("ready");
        triggerDownload();
      }
    }, stepMs);
  };

  const triggerDownload = async () => {
    // Increment download counter in Firestore
    if (materialId) {
      try {
        const downloadedMaterials = JSON.parse(localStorage.getItem('downloadedMaterials') || '[]');
        if (!downloadedMaterials.includes(materialId)) {
          downloadedMaterials.push(materialId);
          localStorage.setItem('downloadedMaterials', JSON.stringify(downloadedMaterials));
          
          await updateDoc(doc(db, "materials", materialId), { 
            downloads: increment(1) 
          });
        }
      } catch (error) {
        console.error("Error updating download count in Firestore:", error);
      }
    }

    // Trigger the actual file download
    const isLocalhost = window.location.hostname === "localhost" || 
                         window.location.hostname === "127.0.0.1" || 
                         window.location.hostname.startsWith("192.168.");
    if (isLocalhost) {
      window.location.href = `https://docs.google.com/uc?export=download&id=${fileId}`;
    } else {
      window.location.href = `/api/download?id=${fileId}&name=${encodeURIComponent(fileName)}`;
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex flex-col items-center relative overflow-hidden">
      {/* Background gradients for premium glassmorphic feel */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-[#FFD700]/5 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/3 w-[250px] h-[250px] bg-emerald-500/5 rounded-full blur-[60px] pointer-events-none" />

      {/* Top banner ad slot (728x90 on Desktop, 320x50 on Mobile) */}
      <div className="w-full flex justify-center py-4 px-2 z-10">
        <div id="ad-slot-top" className="flex items-center justify-center">
          <div className="hidden md:block">
            <BannerAd 
              adKey="460599b54c2ff48b922f509d238da5dc" 
              format="iframe" 
              height={90} 
              width={728} 
              scriptSrc="https://www.highperformanceformat.com/460599b54c2ff48b922f509d238da5dc/invoke.js" 
            />
          </div>
          <div className="block md:hidden">
            <BannerAd 
              adKey="1580001d5d517502f4a88637fa4a71fc" 
              format="iframe" 
              height={50} 
              width={320} 
              scriptSrc="https://www.highperformanceformat.com/1580001d5d517502f4a88637fa4a71fc/invoke.js" 
            />
          </div>
        </div>
      </div>

      <div className="flex flex-1 w-full max-w-7xl z-10 px-4 gap-4">
        {/* Left sidebar ad */}
        <div className="hidden lg:flex w-[160px] shrink-0 justify-center items-start pt-8">
          <div id="ad-slot-left">
            <BannerAd 
              adKey="a589dee8adb4ee32752f08ffa84d6b2f" 
              format="iframe" 
              height={600} 
              width={160} 
              scriptSrc="https://www.highperformanceformat.com/a589dee8adb4ee32752f08ffa84d6b2f/invoke.js" 
            />
          </div>
        </div>

        {/* Center download card */}
        <div className="flex-1 flex flex-col items-center justify-center py-8">
          <div className="glass-card bg-zinc-900/60 border border-white/10 rounded-2xl p-4 sm:p-5 w-full max-w-xs text-center backdrop-blur-xl shadow-2xl">
            {/* Header Icon */}
            <div className="mx-auto w-12 h-12 bg-[#FFD700]/10 rounded-xl flex items-center justify-center mb-3 border border-[#FFD700]/20">
              <FileText className="text-[#FFD700]" size={20} />
            </div>

            <h2 className="text-white text-base font-bold mb-1">Download Center</h2>
            <p className="text-zinc-400 text-[11px] mb-3 px-2 truncate max-w-full font-medium" title={fileName}>
              {fileName}
            </p>

            {stage === "idle" && (
              <button
                onClick={startProcess}
                className="w-full py-2.5 bg-gradient-to-r from-amber-400 to-[#FFD700] text-black font-extrabold rounded-xl transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-[#FFD700]/10 hover:shadow-[#FFD700]/20 flex items-center justify-center gap-1.5 cursor-pointer text-xs"
              >
                <Download size={16} />
                Download Now
              </button>
            )}

            {stage === "processing" && (
              <div>
                <p className="text-[10px] text-zinc-400 mb-2 font-semibold">Preparing your secure link...</p>
                <div className="w-full bg-zinc-800/50 h-1.5 rounded-full overflow-hidden mb-1.5 border border-white/5">
                  <div
                    className="bg-gradient-to-r from-amber-400 to-[#FFD700] h-full transition-all duration-100 ease-out"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <div className="flex justify-between items-center text-[9px] text-zinc-500 font-semibold">
                  <span>{progress}% Completed</span>
                  <span className="flex items-center gap-0.5 text-emerald-400">
                    <ShieldCheck size={10} /> Secure
                  </span>
                </div>
              </div>
            )}

            {stage === "ready" && (
              <div className="space-y-1 py-1">
                <p className="text-emerald-400 text-xs font-extrabold flex items-center justify-center gap-1">
                  <ShieldCheck size={14} /> Download started!
                </p>
                <p className="text-[9px] text-zinc-500">If the download didn't start, check pop-ups blocker.</p>
              </div>
            )}
          </div>

          {/* Mid-page video/banner ad (300x250) */}
          <div className="w-full flex justify-center mt-8">
            <div id="ad-slot-mid">
              <BannerAd 
                adKey="3a20a0c9de1d599239beb32f5556ec91" 
                format="iframe" 
                height={250} 
                width={300} 
                scriptSrc="https://www.highperformanceformat.com/3a20a0c9de1d599239beb32f5556ec91/invoke.js" 
              />
            </div>
          </div>
          
          <div className="mt-6 flex items-center justify-center gap-1.5 text-zinc-500 text-[10px] font-medium">
            <AlertCircle size={12} />
            <span>Ads support our servers to keep learning resources free.</span>
          </div>
        </div>

        {/* Right sidebar ad */}
        <div className="hidden lg:flex w-[160px] shrink-0 justify-center items-start pt-8">
          <div id="ad-slot-right">
            <BannerAd 
              adKey="89c8057a29aa045de216722e2c7fdc99" 
              format="iframe" 
              height={300} 
              width={160} 
              scriptSrc="https://www.highperformanceformat.com/89c8057a29aa045de216722e2c7fdc99/invoke.js" 
            />
          </div>
        </div>
      </div>

      {/* Bottom banner ad (Native wrapper or 468x60 banner) */}
      <div className="w-full flex flex-col items-center justify-center py-4 px-2 z-10 gap-4">
        <div id="ad-slot-bottom" className="flex flex-col items-center justify-center gap-4">
          {/* Native Social Bar Ad */}
          <NativeAdSlot 
            containerId="container-f086433aa457e5252b84f8136e979116" 
            scriptSrc="https://pl30438977.effectivecpmnetwork.com/f086433aa457e5252b84f8136e979116/invoke.js" 
          />
          {/* 468x60 Banner Ad */}
          <BannerAd 
            adKey="c7c3d1f2df201accee2e5e6dd5ae4f3e" 
            format="iframe" 
            height={60} 
            width={468} 
            scriptSrc="https://www.highperformanceformat.com/c7c3d1f2df201accee2e5e6dd5ae4f3e/invoke.js" 
          />
        </div>
      </div>
    </div>
  );
}
